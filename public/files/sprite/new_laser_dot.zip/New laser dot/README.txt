New laser dot
Made by: [Rinzler V2.0](http://gamebanana.com/members/1307176)

installation:

1-Extract the New laser dot.Zip
2-Copy or cut the folder valve folder and paste in your hl1
3-Enjoy
