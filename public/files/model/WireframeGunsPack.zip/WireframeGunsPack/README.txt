Hello my name is Hons.Elle, i am the creator of the modelpack and i hope you enjoy! :-)
These models do not work with hd models enabled, so make sure the "use hd models if available" option in-game is turned off.
For the best experience set default_fov to about 105.

To install the modelpack, just put the "WireframeGunsPack" folder in the following folder: "C:\Program Files (x86)\Steam\steamapps\common\Half-Life"
